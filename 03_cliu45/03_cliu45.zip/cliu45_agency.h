#ifndef CLIU45_AGENCY_H
#define CLIU45_AGENCY_H
#include "cliu45_team.h"
#include "cliu45_player.h"

void AddTeam();

void AddPlayer();

void Display();

void SortPlayer();

void FindPlayer();
#endif
